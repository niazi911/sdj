<h1 align="center">
  SDJ-PRO
</h1>
</div>
<p align="center">
  Made with ❤️ by <a href="https://www.facebook.com/HATERZKAABUUGZAINI2">SHAHZAIN-SDJ_</a>
</p>
<p align="center">

<a href="https://github.com/SHAHZAIN-SDJ/followers">
<img title="Followers" src="https://img.shields.io/github/followers/SHAHZAIN-SDJ?label=Followers&color=blue&style=flat-square"></a>
<a href="https://github.com/SHAHZAIN-SDJ/termux-style/stargazers/">
  <a href="https://github.com/SHAHZAIN-SDJ/SDJ-PRO">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/SHAHZAIN-SDJ/SDJ-PRO.svg"/>
  </a>
  <a href="https://github.com/SHAHZAIN-SDJ/SDJ-PRO">
    <img alt="Language" src="https://img.shields.io/github/languages/count/SHAHZAIN-SDJ/SDJ-PRO.svg"/>

  </a>
</div>
<p align="center">

#### Install script on Termux
```bash
$ apt update 
$ apt upgrade
$ pkg install python2
$ pkg install git
$ git clone https://github.com/SHAHZAIN-SDJ/SDJ-PRO
$ pip2 install requests bs4
$ pip2 install futures
```
#### Run script
```bash
$ cd SDJ-PRO
$ python2 SDJ
```
#### MY SOCIAL MEDIA

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/SHAHZAIN-SDJ) [![](https://img.shields.io/badge/Twitter-blue?logo=Twitter&logoColor=White&labelColor=white)](https://mobile.twitter.com/sdj)
[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/HATERZKAABBUGZAINI2)[![](https://img.shields.io/badge/Instagram-red?logo=Instagram&logoColor=red&labelColor=white)](https://www.instagram.com/sdj/) [![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/923417264556?text=Asalamualaikum+bro)

𝚅𝙸𝚂𝙸𝚃𝙾𝚁𝚂 𝙲𝙾𝚄𝙽𝚃
 <img src="https://profile-counter.glitch.me/SHAHZAIN-SDJ/count.svg" />
</p>
CREDIT TO : https://github.com/yayan-XD
##### Notice Me : Please SUBSCRIBE OUR YOUTUBE CHANNEL



